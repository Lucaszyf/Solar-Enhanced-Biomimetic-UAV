#include <esp_now.h>
#include <WiFi.h>
#include "bsp_gpio.h"
#include "bsp_servo.h"
#include "bsp_attachment.h"
#include "bsp_usart.h"
#include "bsp_solarpanel.h"
#include "bsp_SW.h"

//变量区
// REPLACE WITH YOUR RECEIVER MAC Address
uint8_t broadcastAddress[] = {0xC4, 0xDE, 0xE2, 0x9D, 0x56, 0xB0};  //接收端代码MAC地址

// 定义串口任务句柄
TaskHandle_t SerialTaskHandle;
// Structure example to send data
typedef struct struct_message {
  char a[32];
  int b;
  float c;
  bool d;
} struct_message;

// Create a struct_message called myData
struct_message myData;

esp_now_peer_info_t peerInfo;

// callback when data is sent
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  Serial.print("\r\nLast Packet Send Status:\t");
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Delivery Success" : "Delivery Fail");
}

void GPIO_INIT(){
  //IO模式初始化
  //爪子：气泵电磁阀气压计
  pinMode(pump_pin, OUTPUT);
  pinMode(e_valve, OUTPUT);
  pinMode(air_sensor_pin, INPUT);
  //爪子：n20，压力，内触碰开关，外触碰开关
  pinMode(claw1_pin, OUTPUT);
  pinMode(claw2_pin, OUTPUT);
  pinMode(claw_pressure_pin, INPUT);  //模拟输入
  pinMode(claw_open_button_pin, INPUT);
  pinMode(claw_sw_pin, INPUT);
  //太阳能板：n20电机，舵机，光照传感器
  pinMode(sp_pin1, OUTPUT);
  pinMode(sp_pin2, OUTPUT);
  pinMode(sp_left_spin_pin, OUTPUT);
  pinMode(sp_right_spin_pin, OUTPUT);
  pinMode(sp_light_sensor_up, INPUT);
  pinMode(sp_light_sensor_down, INPUT);
  //摄像头图传开关
  pinMode(camera_sw, OUTPUT);
}
 
void setup() {
  // Init Serial Monitor
  Serial.begin(115200);
  Serial2.begin(115200);
 
  // Set device as a Wi-Fi Station
  // WiFi.mode(WIFI_STA);
  // if (esp_now_init() != ESP_OK) {
  //   Serial.println("Error initializing ESP-NOW");
  //   return;
  // }
  // esp_now_register_send_cb(OnDataSent);
  // memcpy(peerInfo.peer_addr, broadcastAddress, 6);
  // peerInfo.channel = 0;  
  // peerInfo.encrypt = false;   
  // if (esp_now_add_peer(&peerInfo) != ESP_OK){
  //   Serial.println("Failed to add peer");
  //   return;
  // }
  GPIO_INIT();
  //模块初始化
  servo_init();
  // 创建串口任务
  xTaskCreatePinnedToCore(
      serialEventTask,   // 任务函数
      "SerialEventTask", // 任务名称
      2048,              // 任务堆栈大小
      NULL,              // 任务参数
      1,                 // 任务优先级
      &SerialTaskHandle, // 任务句柄
      1                  // 任务运行在核心1上
  );
  // digitalWrite(claw1_pin, LOW);   //闭合
  // digitalWrite(claw2_pin, HIGH);
  // delay(1000);
  // sp_open(65,1800);  //太阳能板以50bg速度开
  // sp_close(65,1800);//太阳能板以50速度关,延时1800ms
}
 
void loop() {
  // Send message via ESP-NOW
  // esp_err_t result = esp_now_send(broadcastAddress, (uint8_t *) &myData, sizeof(myData));
  //usart_rec1();
  if(sun_state_num == 1)sun_chark();
  // sp_open(65,1800);
  // sp_close(65,1800);
  if(sun_state_input == 1)
  {
    sp_open(55,1800);
    sun_state_input = 0;
  }
  if(sun_state_output == 1)
  {
    sp_close(55,1800);
    sun_state_output = 0;
  }
  // usart_rec();
  // arm_mode=digitalRead(arm_mode_sw);
  // interpret_SW();
  // Serial2.print(arm_mode);
}

void serialEventTask(void *pvParameters) {
  while (1) {
    if (Serial.available() > 0) {
      char receivedData = Serial.read();
      if (receivedData == 'A') {
        digitalWrite(4, HIGH);
        digitalWrite(5, LOW);
      } else if (receivedData == 'B') {
        digitalWrite(4, LOW);
        digitalWrite(5, HIGH);
      } else if (receivedData == 'C') {
        digitalWrite(4, HIGH);
        digitalWrite(5, HIGH);
      } else if (receivedData == 'D') {
        digitalWrite(2, LOW);
      } else if (receivedData == 'E') {
        digitalWrite(2, HIGH);
      } else if (receivedData == 'O') { // 自动追阳模式
        sun_state_num = !sun_state_num;
      } else if (receivedData == 'L') { // 放出太阳能
        sun_state_input = !sun_state_input;
      } else if (receivedData == 'M') { // 收回太阳能
        sun_state_output = !sun_state_output;
      }
      receivedData = 0;
    }
    vTaskDelay(10 / portTICK_PERIOD_MS); // 避免任务过度占用CPU时间
  }
}