#include "bsp_solarpanel.h"

//太阳能启动
int best_angle; //最佳角度
int current_angle=0; //现在角度
int best_light; //最好光线
int current_light;
int default_close_angle=105; //回到机身的角度
int sp_flag;

void sp_close(int sp_speed,int run_time){
  setServoAngle_sp(default_close_angle, 10);
  analogWrite(sp_pin1, 0);
  analogWrite(sp_pin2, sp_speed);
  delay(run_time);//amount of time to close
  analogWrite(sp_pin1, LOW);
  analogWrite(sp_pin2, LOW);
}

void sp_open(int sp_speed,int run_time){
  analogWrite(sp_pin1, sp_speed);
  analogWrite(sp_pin2, 0);
  delay(run_time);//amount of time to open
  analogWrite(sp_pin1, LOW);
  analogWrite(sp_pin2, LOW);
}

void sp_angle_cal(){ //追太阳
  //refresh light
  setServoAngle_sp(0, 10);
  while(current_angle<180){
    setServoAngle_sp(current_angle, 10);
    // current_light=analogRead(light_sensor);
    current_angle++;
    if(current_light>=best_light){
      best_light=current_light;
      best_angle=current_angle;
    }
    if(buffer[1]!=2){
      break;
    }
  }
  while(current_angle>0){
    setServoAngle_sp(current_angle, 10);
    // current_light=analogRead(light_sensor);
    current_angle--;
    if(current_light>=best_light){
      best_light=current_light;
      best_angle=current_angle;
    }
    if(buffer[1]!=2){
      break;
    }
  }
}